
---
name: VCCF Visualization for HBM674.XQFQ.364
figures:
    - name: "Visualization"
      file: vitessce.json
---

This vignette visualizes Region 12. The image shows the segmentation of vasculature and immune cells, and the links between them.
    