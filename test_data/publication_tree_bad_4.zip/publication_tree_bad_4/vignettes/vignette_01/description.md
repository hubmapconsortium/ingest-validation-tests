---
name: Use Case 1
figures:
    - file: osmfish.json
---

## Single-molecule fluorescence in situ hybridization from the mouse somatosensory cortex

Codeluppi et al. used single-molecule fluorescence in situ hybridization (smFISH) to profile the somatosensory cortex in a mouse brain section (Nature Methods 2018). The authors selected 33 marker genes based on previous scRNA-seq findings in the somatosensory cortex and their ability to define cell types. A notable finding from this experiment was the discovery of a transition region defined by the Pyramidal L3/4 excitatory neuron cell type. Using the spatial plot and heatmap in Vitessce, we can reproduce this finding and observe the reported joint expression of markers Lamp5 and Rorb that define the surrounding Pyramidal L2/3 and L4 cell types, respectively. 
